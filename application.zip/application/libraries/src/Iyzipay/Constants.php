<?php

namespace Iyzipay;

class Constants
{
    const SINGLE_INSTALLMENT = 1;
}